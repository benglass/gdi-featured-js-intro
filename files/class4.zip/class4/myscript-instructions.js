/*
=========================
Hints:
=========================

1. To get the value from a form field, use the value property
  Example: 
  
  var age_field = document.querySelector('.age-field');
  var age = age_field.value;
  
2. To prefix one string with another, use the + operator
  Example: 
  
  var pounds = 50;
  var pounds_display = pounds + 'lbs.';
  
3. To update the text contents of an HTML element, assign a value to the innerText field
  Example: 
  
  var message_box = document.getElementById('message-box');
  message_box.innerText = 'Hello!';
  
4. To run a function when an event occurs, use the addEventListener method
  Example: 
  
  var my_form = document.querySelector('#my-form');
  my_form.addEventListener('submit', function() {
    alert('Its submitted!');
  });

5. To cancel a form submission, call the preventDefault function on the event object
  Example: 
  
  var my_form = document.querySelector('#my-form');
  my_form.addEventListener('submit', function() {
    event.preventDefault();
    alert('Its submitted!');
  });

*/

/*
Step 1: Find the tip form and store in a var named tip_form
*/

/*
Step 2: Find the total bill and tip percent fields
a. Find the total bill field and store in a var named total_bill_field
b. Find the tip percent field and store in a var named tip_percent_field
*/

/*
Step 3: Find the total and tip display elements
a. Find the tip display element and store in a var named tip_display
b. Find the total display element and and store in a var named total_display
*/

/*
Step 4: Define a calculate_tip function to: 
a. Calculate the tip 
b. Display the tip 
*/

/*
Step 9: Re-calculate the total and tip when any field changes
a. Find all of the fields and loop through them
b. For each field, calculate the tip when it change
*/

/*
Step 10: Prevent the default submit behavior so hitting enter doesnt submit the form
*/
