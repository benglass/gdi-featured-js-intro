var totalBillField = document.getElementById('total-bill-field');

totalBillField.addEventListener('change', function() {
  console.log('it changed!');
});
